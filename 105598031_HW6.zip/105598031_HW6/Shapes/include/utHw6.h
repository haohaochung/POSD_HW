#ifndef UTHW6_H_INCLUDED
#define UTHW6_H_INCLUDED

#include <string>
#include <iostream>

#include "Parser.h"


// Problem 1
// Use  �def� instruction to insert ShapeMedia and ComboMedia and give name to each ShapeMedia and ComboMedia.
TEST(insertMedia, Parser) {
    //std::string input = "def cSmall = Circle(2,1,1)";
    //std::string output = "Circle(2,1,1)";

    Parser p;
    p.textUI();
}


#endif // UTHW6_H_INCLUDED
