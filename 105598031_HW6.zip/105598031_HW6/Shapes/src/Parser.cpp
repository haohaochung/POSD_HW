//#include "Parser.h"


//void Parser::textUI() {

    //while (true) {

      //  char str[100];
        //cout<< ":- ";
        //cin.getline(str, 100);
        //char *pch;
        //char *delimiters = " =,()";
        //pch = strtok(str, delimiters);

        //while(pch!=NULL) {
          //  cout<<pch<<endl;
           // v.push_back(pch);
            //pch = strtok(NULL, delimiters);
       // }

        //if(v[0]== "def") {
         //   defineMedia();
        //}
        //else {

        //}

        //v.clear(); //Initialization
    //}
//}


//void Parser::defineMedia(){


  //   string mediaName = v[1];

 //    for(int i =2; i < v.size();i++) {

        //if(v[i] == "Circle") {
            //mb.push_back(new ShapeMediaBuilder());
            //mb.insert->buildShapeMedia(new Circle(v[3], v[4], v[5]);
        //}

        //else if(v[i] == "Triangle") {

        //}

        //else {
          //  break;
       // }
    // }

//}

